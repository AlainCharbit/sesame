<?php

include_once('Connexion.php');

class Personne{

	private $ID;
	private $Nom;
	private $Prenom;
	private $Mail;
	private $Age;

	function __construct($p_nom, $p_prenom, $p_mail, $p_age)
	{
		$this -> Nom = $p_nom;
		$this -> Prenom = $p_prenom;
		$this -> Mail = $p_mail;
		$this -> Age = $p_age;
	}
	
	// Affiche toutes les personnes
	public static function viewAll()
	{
		$db = Connexion::ouvrir();
		$req = $db->query('SELECT * FROM Personne');
		$reponse = $req->fetchAll();
		return $reponse ? $reponse : "Erreur : Il n'y a personne dans la liste.";
	}

	// Affiche une personne
	public function view($ID)
	{
		$db = Connexion::ouvrir();
		$req = $bdd->query('SELECT * FROM Personne WHERE ID ="' . $ID . '"');
		$reponse = $req->fetchAll();
		return $reponse ? $reponse : "Erreur : Utilisateur non trouvé.";
	}

	// Ajoute une Personne
	public function add($Nom, $Prenom, $Mail, $Age)
	{
		$db = Connexion::ouvrir();
		$req=$db->prepare("INSERT INTO Personne (Nom, Prenom, Mail, Age) VALUES (:Nom, :Prenom, :Mail, :Age)");
		$req->bindParam(':Nom', $Nom);
		$req->bindParam(':Prenom', $Prenom);
		$req->bindParam(':Mail', $Mail);
		$req->bindParam(':Age', $Age);
		$req->execute();
	}

	// Modifie une Personne
	public function edit($ID)
	{
		$db = Connexion::ouvrir();
		$req=$db->prepare('UPDATE Personne SET Nom = :Nom, Prenom = :Prenom, Mail = :Mail, Age = :Age WHERE ID = :ID');
		$req->bindParam(':Nom', $Nom);
		$req->bindParam(':Prenom', $Prenom);
		$req->bindParam(':Mail', $Mail);
		$req->bindParam(':Age', $Age);
		$req->bindParam(':ID', $ID);
		$req->execute();
	}

	// Supprime une Personne
	public function delete($ID)
	{
		$db = Connexion::ouvrir();
		$req=$db->prepare('DELETE FROM Personne WHERE ID = :ID');
		$req->bindParam(':ID', $ID);
		$req->execute();
	}
}

?>