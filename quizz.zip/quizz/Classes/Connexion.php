<?php

class Connexion
{

	function __construct()
	{

	}

	public static function ouvrir() {
		try 
		{
			$db = new PDO('mysql:host=localhost; dbname=quizz', 'root', '');
			return $db;
		} 
		catch (Exception $e) {
			die('Erreur : ' .$e->getMessage());
		}
	}
}

?>