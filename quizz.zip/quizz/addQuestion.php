﻿<!DOCTYPE html>
<html>
<head>
	<title>Quizz</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
	<form class="form-horizontal" method="post" action="addQuestion.php">
	<fieldset>
	
	<!-- Form Name -->
	<legend>Ajouter une question</legend>
	
	<!-- Select Basic -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="idDiscipline">Discipline</label>
	  <div class="col-md-4">
	    <select id="idDiscipline" name="idDiscipline" class="form-control">
	      <option value="1">Anglais</option>
	      <option value="2">Allemand</option>
	      <option value="3">Espagnol</option>
	      <option value="4">Arabe</option>
	      <option value="5">Chinois</option>
	      <option value="6">Italien</option>
	      <option value="7">Portugais</option>
	      <option value="8">Russe</option>
	      <option value="9">Logique</option>
	    </select>
	  </div>
	</div>
	
	<!-- Select Basic -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="difficulteQuestion">Difficulté</label>
	  <div class="col-md-4">
	    <select id="difficulteQuestion" name="difficulteQuestion" class="form-control">
	      <option value="1">Facile</option>
	      <option value="2">Normal</option>
	      <option value="3">Difficile</option>
	    </select>
	  </div>
	</div>

	<!-- Select Basic -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="recurrenceQuestion">Réccurence</label>
	  <div class="col-md-4">
	    <select id="recurrenceQuestion" name="recurrenceQuestion" class="form-control">
	      <option value="1">Faible</option>
	      <option value="2">Normal</option>
	      <option value="3">Elevé</option>
	    </select>
	  </div>
	</div>

	<!-- Text input-->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="enonceQuestion">Question</label>  
	  <div class="col-md-4">
	  <input id="enonceQuestion" name="enonceQuestion" type="text" placeholder="" class="form-control input-md" required="">
	  </div>
	</div>

	<!-- Text input-->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="ennonceReponse1">Réponse 1</label>  
	  <div class="col-md-4">
	  <input id="ennonceReponse1" name="ennonceReponse1" type="text" placeholder="" class="form-control input-md" required="">
	  </div>
	</div>

	<!-- Multiple Radios -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="resultatReponse1"></label>
	  <div class="col-md-4">
	  <div class="radio">
	    <label for="resultatReponse1">
	      <input type="radio" name="resultatReponse1" id="resultatReponse1" value="1" checked="checked">
	      Réponse Juste
	    </label>
		</div>
	  <div class="radio">
	    <label for="resultatReponse1">
	      <input type="radio" name="resultatReponse1" id="resultatReponse1" value="0">
	      Réponse Fausse
	    </label>
		</div>
	  </div>
	</div>

	<!-- Text input-->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="ennonceReponse2">Réponse 2</label>  
	  <div class="col-md-4">
	  <input id="ennonceReponse2" name="ennonceReponse2" type="text" placeholder="" class="form-control input-md" required="">
	  </div>
	</div>

	<!-- Multiple Radios -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="resultatReponse2"></label>
	  <div class="col-md-4">
	  <div class="radio">
	    <label for="resultatReponse2">
	      <input type="radio" name="resultatReponse2" id="resultatReponse2" value="1" checked="checked">
	      Réponse Juste
	    </label>
		</div>
	  <div class="radio">
	    <label for="resultatReponse2">
	      <input type="radio" name="resultatReponse2" id="resultatReponse2" value="0">
	      Réponse Fausse
	    </label>
		</div>
	  </div>
	</div>

	<!-- Text input-->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="ennonceReponse3">Réponse 3</label>  
	  <div class="col-md-4">
	  <input id="ennonceReponse3" name="ennonceReponse3" type="text" placeholder="" class="form-control input-md" required="">
	  </div>
	</div>

	<!-- Multiple Radios -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="resultatReponse3"></label>
	  <div class="col-md-4">
	  <div class="radio">
	    <label for="resultatReponse3">
	      <input type="radio" name="resultatReponse3" id="resultatReponse3" value="1" checked="checked">
	      Réponse Juste
	    </label>
		</div>
	  <div class="radio">
	    <label for="resultatReponse3">
	      <input type="radio" name="resultatReponse3" id="resultatReponse3" value="0">
	      Réponse Fausse
	    </label>
		</div>
	  </div>
	</div>

	<!-- Text input-->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="ennonceReponse4">Réponse 4</label>  
	  <div class="col-md-4">
	  <input id="ennonceReponse4" name="ennonceReponse4" type="text" placeholder="" class="form-control input-md" required="">
	  </div>
	</div>

	<!-- Multiple Radios -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="resultatReponse4"></label>
	  <div class="col-md-4">
	  <div class="radio">
	    <label for="resultatReponse4">
	      <input type="radio" name="resultatReponse4" id="resultatReponse4" value="1" checked="checked">
	      Réponse Juste
	    </label>
		</div>
	  <div class="radio">
	    <label for="resultatReponse4">
	      <input type="radio" name="resultatReponse4" id="resultatReponse4" value="0">
	      Réponse Fausse
	    </label>
		</div>
	  </div>
	</div>

	<!-- Text input-->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="correctionReponse">Correction</label>  
	  <div class="col-md-4">
	  <input id="correctionReponse" name="correctionReponse" type="text" placeholder="" class="form-control input-md" required="">
	  </div>
	</div>

	<!-- Button -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="submit"></label>
	  <div class="col-md-4">
	    <button id="submit" name="submit" class="btn btn-primary">Envoyer la question</button>
	  </div>
	</div>
	
	</fieldset>
	</form>
</body>
</html>

<?php

// Connexion à la base de donnée.
include_once('Classes/Connexion.php');
$db = Connexion::ouvrir();

if (isset($_POST['idDiscipline']) && isset($_POST['difficulteQuestion']) && isset($_POST['enonceQuestion']) && isset($_POST['recurrenceQuestion']) && isset($_POST['correctionReponse']) && isset($_POST['ennonceReponse1']) && isset($_POST['resultatReponse1']) && isset($_POST['ennonceReponse2']) && isset($_POST['resultatReponse2']) && isset($_POST['ennonceReponse3']) && isset($_POST['resultatReponse3']) && isset($_POST['ennonceReponse4']) && isset($_POST['resultatReponse4']))
{

	$idDiscipline = htmlspecialchars($_POST['idDiscipline']);
	
	if (isset($_SESSION['ID']))
	{
		$idAdmin = $_SESSION['ID'];
	}
	else
	{
		$idAdmin = 1;	
	}
	
	$difficulteQuestion = htmlspecialchars($_POST['difficulteQuestion']);
	$enonceQuestion = htmlspecialchars($_POST['enonceQuestion']);
	$recurrenceQuestion = htmlspecialchars($_POST['recurrenceQuestion']);
	
	$req=$db->prepare("INSERT INTO questions (idDiscipline, idAdmin, difficulteQuestion, enonceQuestion, recurrenceQuestion) VALUES (:idDiscipline, :idAdmin, 	:difficulteQuestion, :enonceQuestion, :recurrenceQuestion)");
	$req->bindParam(':idDiscipline', $idDiscipline);
	$req->bindParam(':idAdmin', $idAdmin);
	$req->bindParam(':difficulteQuestion', $difficulteQuestion);
	$req->bindParam(':enonceQuestion', $enonceQuestion);
	$req->bindParam(':recurrenceQuestion', $recurrenceQuestion);
	$req->execute();
	
	
	$idQuestion = $db->lastInsertId();
	$correctionReponse = htmlspecialchars($_POST['correctionReponse']);
	
	
	$ennonceReponse1 = htmlspecialchars($_POST['ennonceReponse1']);
	$resultatReponse1 = htmlspecialchars($_POST['resultatReponse1']);
	
	$req=$db->prepare("INSERT INTO reponses (idQuestion, ennonceReponse, resultatReponse, correctionReponse) VALUES (:idQuestion, :ennonceReponse, :resultatReponse, 	:correctionReponse)");
	$req->bindParam(':idQuestion', $idQuestion);
	$req->bindParam(':ennonceReponse', $ennonceReponse1);
	$req->bindParam(':resultatReponse', $resultatReponse1);
	$req->bindParam(':correctionReponse', $correctionReponse);
	$req->execute();
	
	
	$ennonceReponse2 = htmlspecialchars($_POST['ennonceReponse2']);
	$resultatReponse2 = htmlspecialchars($_POST['resultatReponse2']);
	
	$req=$db->prepare("INSERT INTO reponses (idQuestion, ennonceReponse, resultatReponse, correctionReponse) VALUES (:idQuestion, :ennonceReponse, :resultatReponse, 	:correctionReponse)");
	$req->bindParam(':idQuestion', $idQuestion);
	$req->bindParam(':ennonceReponse', $ennonceReponse2);
	$req->bindParam(':resultatReponse', $resultatReponse2);
	$req->bindParam(':correctionReponse', $correctionReponse);
	$req->execute();
	
	
	$ennonceReponse3 = htmlspecialchars($_POST['ennonceReponse3']);
	$resultatReponse3 = htmlspecialchars($_POST['resultatReponse3']);
	
	$req=$db->prepare("INSERT INTO reponses (idQuestion, ennonceReponse, resultatReponse, correctionReponse) VALUES (:idQuestion, :ennonceReponse, :resultatReponse, 	:correctionReponse)");
	$req->bindParam(':idQuestion', $idQuestion);
	$req->bindParam(':ennonceReponse', $ennonceReponse3);
	$req->bindParam(':resultatReponse', $resultatReponse3);
	$req->bindParam(':correctionReponse', $correctionReponse);
	$req->execute();
	
	
	$ennonceReponse4 = htmlspecialchars($_POST['ennonceReponse4']);
	$resultatReponse4 = htmlspecialchars($_POST['resultatReponse4']);
	
	$req=$db->prepare("INSERT INTO reponses (idQuestion, ennonceReponse, resultatReponse, correctionReponse) VALUES (:idQuestion, :ennonceReponse, :resultatReponse, 	:correctionReponse)");
	$req->bindParam(':idQuestion', $idQuestion);
	$req->bindParam(':ennonceReponse', $ennonceReponse4);
	$req->bindParam(':resultatReponse', $resultatReponse4);
	$req->bindParam(':correctionReponse', $correctionReponse);
	$req->execute();

	echo '<h4 class="addQuestion">Votre question "'. $enonceQuestion . '" a bien été ajoutée.</h4>';
}

?>