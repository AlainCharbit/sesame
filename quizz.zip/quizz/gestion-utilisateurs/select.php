﻿<?php

// Connexion à la base de donnée.
include_once('../Classes/Connexion.php');

// Sélection de l'utilisateur
$ID = $_POST['ID'];

// Sélection d'une ligne dans la base de donnée.
$db = Connexion::ouvrir();
$req = $db->prepare('SELECT * FROM personne WHERE ID = ?');
$req->execute(array($ID));

// Affichage du résultat
while ($donnees = $req->fetch())
{
	echo 'Nom : ' . $donnees['Nom'] . '<br/>Prénom : ' . $donnees['Prenom'] . '<br/>Mail : ' . $donnees['Mail'] . '<br/>Age : ' . $donnees['Age'] . '';
}

?>