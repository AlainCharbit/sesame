<?php

// Connexion à la base de donnée.
include_once('../Classes/Connexion.php');

require_once('../classes/Personne.php');
$db = Connexion::ouvrir();

?>