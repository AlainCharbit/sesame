﻿<?php

// Connexion à la base de donnée.
include_once('../Classes/Connexion.php');

// Récupération des valeurs du formulaire.
$Nom = $_POST['Nom'];
$Prenom = $_POST['Prenom'];
$Mail = $_POST['Mail'];
$Age = $_POST['Age'];

// Insertion d'une ligne dans la base de donnée.
$db = Connexion::ouvrir();
$req=$db->prepare("INSERT INTO personne (Nom, Prenom, Mail, Age) VALUES (:Nom, :Prenom, :Mail, :Age)");
$req->bindParam(':Nom', $Nom);
$req->bindParam(':Prenom', $Prenom);
$req->bindParam(':Mail', $Mail);
$req->bindParam(':Age', $Age);
$req->execute();
header('Location: index.html');

?>