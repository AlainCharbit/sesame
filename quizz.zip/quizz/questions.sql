-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- GÃ©nÃ©rÃ© le :  Jeu 19 Mai 2016 à 14:43
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de donnÃ©es :  `quizz`
--

-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `idDiscipline` int(10) NOT NULL,
  `idAdmin` int(10) NOT NULL,
  `difficulteQuestion` int(2) NOT NULL,
  `enonceQuestion` varchar(255) NOT NULL,
  `recurrenceQuestion` int(3) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=134 ;

--
-- Contenu de la table `questions`
--

INSERT INTO `questions` (`ID`, `idDiscipline`, `idAdmin`, `difficulteQuestion`, `enonceQuestion`, `recurrenceQuestion`) VALUES
(52, 1, 1, 1, 'Thanks to the Internet, people.... necessarily have to use libraries to get .... .', 1),
(54, 1, 1, 1, 'Sean was very upset yesterday, you .... to him so harshly.', 1),
(55, 1, 1, 1, 'Bob .... to work in bad weather.', 1),
(56, 1, 1, 1, 'I .... a good skier, but I’m getting a bit old now.', 1),
(57, 1, 1, 1, 'John: &quot;This is a very interesting .... Plan&quot;<br/>Jack: &quot;....&quot;', 1),
(58, 1, 1, 1, 'He stopped .... a long time ago.', 1),
(59, 1, 1, 1, 'He .... be very rich to have such a beautiful house.', 1),
(60, 1, 1, 1, 'Although the job centre gave me some .... I found a lot more .... on the Internet.', 1),
(61, 1, 1, 1, 'What time does your flight take .... tomorrow morning?', 1),
(62, 1, 1, 1, '.... has been spent on new roads.', 1),
(63, 1, 1, 1, 'Her job includes travelling, and the petrol .... by the firm.', 1),
(64, 1, 1, 1, 'Last week, the government .... organise a special evacuation plan due to the severe flooding in the north of the country.', 1),
(65, 1, 1, 1, 'It is high time he .... of his parents? home. He is going to be 35 next year.', 1),
(66, 1, 1, 1, '.... had they arrived in the tropics, .... they were told about the mosquitoes.', 1),
(67, 1, 1, 1, 'Because there are .... tourists coming into the country, there is .... money circulating in the economy.', 1),
(68, 1, 1, 1, 'Since the beginning of this summer holiday, she .... in this restaurant.', 1),
(69, 1, 1, 1, 'If I .... more time, I .... off in Paris on my way back to London.', 1),
(70, 1, 1, 1, 'Could you give me some .... on how to .... these children?', 1),
(71, 1, 1, 1, 'How long .... in your current job?', 1),
(72, 1, 1, 1, 'Many students of English .... take tests.', 1),
(73, 1, 1, 1, 'Most people will agree that .... you work, .... you will be in life.', 1),
(74, 1, 1, 1, 'His family had asked for his help as they were having difficulty in .... .', 1),
(75, 1, 1, 1, 'We .... a contract last year and it is still valid.', 1),
(76, 1, 1, 1, 'Some people try to improve their English by .... the BBC.', 1),
(77, 1, 1, 1, 'She wants .... to her office right now.', 1),
(78, 1, 1, 1, 'One of the biggest .... of travelling by car is that it is much slower than flying.', 1),
(79, 1, 1, 1, 'Ten of us were taken ill .... a party we were at in Sydney. I felt ill .... a couple of days, but was fine after that.', 1),
(80, 1, 1, 1, 'He gave me .... about investing money.', 1),
(81, 1, 1, 1, 'It is said that Chinese is perhaps the world?s .... language to learn.', 1),
(82, 1, 1, 1, 'Russia may well be the .... country in the world, but it is by no means the .... .', 1),
(83, 1, 1, 1, 'His mother is dead. Who will .... him now ?', 1),
(84, 1, 1, 1, 'Always look before .... the road.', 1),
(85, 1, 1, 1, 'Which ONE word is NOT possible in the following sentence : <br/>It .... rain this afternoon, so you?d better take an umbrella with you.', 1),
(86, 1, 1, 1, 'I can?t hear you. Speak .... .', 1),
(87, 1, 1, 1, 'He really wanted to go to Ibiza so he .... his uncle and aunt.', 1),
(88, 1, 1, 1, 'Hardly had he seen the dog, .... away.', 1),
(89, 1, 1, 1, 'As we have a lot of orders we have decided to .... two new employees.', 1),
(90, 1, 1, 1, 'That ladder doesn?t look very safe, you .... to have it .... .', 1),
(91, 1, 1, 1, 'She .... to this town five years ago.', 1),
(92, 1, 1, 1, 'Who prevented her .... part in the school play?', 1),
(93, 9, 1, 1, 'D''aprÃ¨s une enquÃªte, les femmes en France passent en moyenne 10 mn devant la glace le matin, 5 mn l''aprÃ¨s-midi et 5 mn le soir.&lt;br/&gt;Combien de temps passent-elles en moyenne devant la glace en 5 ans (on suppose que toutes les annÃ©es ont 365 jour', 1),
(94, 9, 1, 1, 'Pour sa nouvelle maison, Victor achÃ¨te une baignoire Ã  660 &amp;euro;uros qu''il paie en trois fois. La premiÃ¨re fois, il verse 1/3 de la somme, puis la deuxiÃ¨me fois les 3/5 du reste.&lt;br/&gt;Combien verse-t-il la troisiÃ¨me fois ?', 1),
(95, 9, 1, 1, 'Le nombre 0,000000631 s''Ã©crit aussi :', 1),
(97, 9, 1, 1, 'Dans une classe de 20 Ã©lÃ¨ves, combien peut-on former de groupes de travail diffÃ©rents de 3 Ã©lÃ¨ves chacun ?', 1),
(98, 9, 1, 1, 'Un tÃ©traÃ¨dre rÃ©gulier est composÃ© de 4 faces identiques qui sont 4 triangles Ã©quilatÃ©raux. La somme des longueurs des arÃªtes de ce tÃ©traÃ¨dre est 24 cm. Quelle est la longueur dâ€™une arÃªte de ce tÃ©traÃ¨dre ?', 1),
(99, 9, 1, 1, 'Un litre de mÃ©lange pour tondeuse contient 6 % dâ€™huile. Quel volume dâ€™essence pure doit-on rajouter Ã  ce mÃ©lange pour que le nouveau mÃ©lange obtenu contienne 4 % dâ€™huile ?', 1),
(100, 9, 1, 1, 'On rÃ©alise un puzzle de 20 cm sur 30 cm avec des piÃ¨ces qui mesurent en moyenne 15 mm sur 20 mm. Combien le puzzle contient-il de piÃ¨ces ?', 1),
(101, 9, 1, 1, '&lt;i&gt;x&lt;/i&gt; Ã©tant un nombre strictement positif, on note &lt;i&gt;V&lt;/i&gt; le volume dâ€™un cube de cÃ´tÃ© &lt;i&gt;x&lt;/i&gt; et on note &lt;i&gt;Vâ€™&lt;/i&gt; le volume dâ€™un cube de cÃ´tÃ© &lt;i&gt;x&lt;/i&gt;/2.&lt;br&gt;Quelle relatio', 1),
(102, 9, 1, 1, 'Par combien de zÃ©ros se termine le produit : 1x2x3x4x5x6x7x â€¦ x20 ?', 1),
(103, 9, 1, 2, 'On dÃ©sire acheter un grand nombre de gÃ¢teaux Ã  un pÃ¢tissier.&lt;br/&gt;Les 10 premiers gÃ¢teaux achetÃ©s coÃ»tent le prix habituel, soit 42 &amp;euro;uros les 10. Chaque gÃ¢teau supplÃ©mentaire achetÃ© coÃ»te 3 &amp;euro;uros.&lt;br/&gt;Combien doit-o', 1),
(104, 9, 1, 2, 'Une balle est lÃ¢chÃ©e dâ€™une hauteur de 100 cm. A chaque rebond la hauteur atteinte par la balle diminue de 10 %. Quelle est la hauteur atteinte par la balle aprÃ¨s le 3&lt;sup&gt;Ã¨me&lt;/sup&gt; rebond ?', 1),
(105, 9, 1, 2, 'Quel est le nombre de chiffres de l''entier 5&lt;sup&gt;8&lt;/sup&gt;x2&lt;sup&gt;8 ?', 1),
(106, 9, 1, 2, 'Un terrain de jeux a une forme circulaire de 40 m de diamÃ¨tre.&lt;br/&gt;La municipalitÃ© a dÃ©cidÃ© de l''entourer d''une bande de gazon de largeur 4 m.&lt;br/&gt;Le prix du mÂ² de gazon, achetÃ© et posÃ©, est estimÃ© Ã  5 &amp;euro;uros.&lt;br/&gt;Quel e', 1),
(107, 9, 1, 2, 'Si les dimensions dâ€™un rectangle augmentent de 20 %, son aire augmente de :', 1),
(108, 9, 1, 2, 'La diffÃ©rence entre le carrÃ© du double de 2/3 et lâ€™opposÃ© du carrÃ© de 3/2 est :', 1),
(109, 9, 1, 2, 'En 2004, une compagnie aÃ©rienne a effectuÃ© 50 % de ses vols vers lâ€™Europe et lâ€™autre moitiÃ© vers les CaraÃ¯bes. Entre 2004 et 2005, le nombre total de vols a baissÃ© de 10 % et le pourcentage de vols Ã  destination des CaraÃ¯bes est passÃ© de 50 % ', 1),
(110, 9, 1, 2, 'Une machine-outil trie et met sous enveloppe des cartes postales par paquets de 4. &lt;br/&gt;Cette machine sâ€™arrÃªte dÃ¨s quâ€™il reste moins de 4 cartes. On charge 415679 cartes dans la machine. Combien restera t-il de cartes lorsquâ€™elle sâ€™arrÃªte', 1),
(111, 9, 1, 2, 'Un bateau met 2 heures pour traverser la Manche Ã  une vitesse de 8 nÅ“uds. SimultanÃ©ment, cinq bateaux identiques partent pour le mÃªme trajet.&lt;br/&gt; Combien mettront-ils de temps pour rejoindre lâ€™autre rive ?', 1),
(112, 9, 1, 2, 'Un cylindre creux en inox, utilisÃ© pour la fabrication dâ€™un meuble de luxe, mesure 20 cm de diamÃ¨tre et 60 cm de hauteur.&lt;br/&gt;Le crÃ©ateur envisage de recouvrir sa surface extÃ©rieure dâ€™un cuir de haut de gamme. Le coÃ»t du mÃ¨tre carrÃ© du cu', 1),
(113, 9, 1, 3, 'Une des solutions de lâ€™Ã©quation &lt;i&gt;x&lt;/i&gt;&lt;sup&gt;2&lt;/sup&gt;-9x10&lt;sup&gt;4&lt;/sup&gt; = 0 est...', 1),
(114, 9, 1, 3, 'Le prix dâ€™un diamant est proportionnel au carrÃ© de son poids. Un diamant de 0,4 gramme vaut 6000 &amp;euro;uros.&lt;br/&gt;Quel est le poids dâ€™un diamant dâ€™une valeur de 13500 &amp;euro;uros ?', 1),
(115, 9, 1, 3, 'On a rempli d''eau un bidon cylindrique jusqu''Ã  une hauteur &lt;i&gt;h&lt;/i&gt;.&lt;br/&gt;On a versÃ© ensuite cette eau dans un autre bidon cylindrique dont le diamÃ¨tre est le double du diamÃ¨tre du bidon prÃ©cÃ©dent.&lt;br/&gt;La hauteur de l''eau obte', 1),
(116, 9, 1, 3, 'Sachant que la superficie du cercle est de 314 cmÂ², quelle est la diagonale du carrÃ© ?', 1),
(117, 9, 1, 3, 'Le prix initial de la matiÃ¨re premiÃ¨re M est de 20 â‚¬ le kilogramme. Son prix a augmentÃ© de 100 % par an.&lt;br/&gt;Le prix du kilogramme de M dÃ©passera 900 â‚¬ au bout de...', 1),
(118, 9, 1, 3, 'Sur une banquise, vivait, en mai 2003, une colonie de 500 pingouins.&lt;br/&gt;Lorsque lâ€™hiver est rigoureux, la population des pingouins diminue de 20 %, sinon elle augmente de 10 %. Entre mai 2003 et mai 2005, il nâ€™y a eu quâ€™un hiver rigoureux.&lt', 1),
(119, 9, 1, 3, 'Un rÃ©servoir dâ€™eau peut alimenter 200 maisons pendant 12 jours. Pendant combien de temps peut-il alimenter 240 maisons ?', 1),
(120, 9, 1, 3, 'Un escargot est tombÃ© dans un puits de 10 mÃ¨tres de profondeur. &lt;br/&gt;Combien de jours lui faudra-t-il pour sortir de ce puits, sachant que, le jour, il monte de 3 mÃ¨tres, que, durant la nuit, il redescend de 2 mÃ¨tres, et qu''il dÃ©bute son ascens', 1),
(121, 9, 1, 3, 'Un hÃ´tel dont le tarif habituel pour une nuit est de 200 &amp;euro;uros propose une nouvelle formule Â« spÃ©ciale long sÃ©jour Â». La formule propose une base forfaitaire de 500 &amp;euro;uros Ã  laquelle sâ€™ajoute un prix de 150 &amp;euro;uros par nuit', 1),
(122, 9, 1, 3, 'Combien trouve-t-on, au total, de carrÃ©s dans la figure ci-dessous ?&lt;br/&gt;&lt;center&gt;&lt;img src=&quot;carres.png&quot;&gt;&lt;/center&gt;', 1),
(123, 9, 1, 1, 'Un diviseur de 30 est un nombre entier &lt;i&gt;k&lt;/i&gt; strictement positif tel que &lt;sup&gt;30&lt;/sup&gt;&amp;frasl;&lt;sub&gt;&lt;i&gt;k&lt;/i&gt;&lt;/sub&gt; est un nombre entier.&lt;br/&gt;Le nombre de diviseurs de 30 est...', 1),
(124, 9, 1, 2, 'Un mÃ©decin doit visiter dans la matinÃ©e trois patients &lt;i&gt;A&lt;/i&gt;, &lt;i&gt;B&lt;/i&gt; et &lt;i&gt;C&lt;/i&gt;. Sachant quâ€™il souhaite rendre visite au patient &lt;i&gt;C&lt;/i&gt; avant le patient &lt;i&gt;B&lt;/i&gt;, de combien de faÃ§on', 1),
(125, 9, 1, 3, 'Une espÃ¨ce animale trÃ¨s menacÃ©e voit sa population baisser de 20 % chaque dÃ©cennie par rapport Ã  la dÃ©cennie prÃ©cÃ©dente. Au bout de quarante ans, que peut-on dire de cette espÃ¨ce ?', 1),
(126, 9, 1, 1, 'Un commerÃ§ant a achetÃ© un nombre &lt;i&gt;N&lt;/i&gt; de produits identiques dont il est sÃ»r de vendre tout le stock.&lt;br/&gt;Si le prix de vente unitaire est fixÃ© Ã  5 &amp;euro;uros, il gagne 1 700 &amp;euro;uros.&lt;br/&gt;Si le prix de vente uni', 1),
(127, 9, 1, 2, 'Lors dâ€™un mois de 30 jours, trois lundis sont des jours pairs. Quel jour de la semaine tombe le 25 du mois ?', 1),
(128, 9, 1, 3, 'Deux entiers &lt;i&gt;k&lt;/i&gt; et &lt;k&gt;p&lt;/i&gt; vÃ©rifient les relations &lt;i&gt;k&lt;/i&gt; + &lt;i&gt;p&lt;/i&gt; = 20 et &lt;i&gt;k&lt;/i&gt;.&lt;i&gt;p&lt;/i&gt; = 91. Quelle est la valeur de &lt;i&gt;k&lt;/i&gt;&lt;sup&gt;2&lt;/sup&gt; + &', 1),
(129, 9, 1, 2, 'Lâ€™annÃ©e derniÃ¨re, lâ€™Ã¢ge de Laura Ã©tait un multiple de 8, lâ€™annÃ©e prochaine son Ã¢ge sera un multiple de 9.&lt;br/&gt;Parmi les propositions suivantes, quel est son Ã¢ge ?', 1),
(130, 9, 1, 1, 'Un sac contient 20 jetons. Les jetons peuvent Ãªtre de couleur blanche ou rouge. Il y a au moins un jeton blanc. Chaque fois que lâ€™on tire au hasard 2 jetons du sac, il y a au moins un jeton rouge. Quel est le nombre de jetons rouges ?', 1),
(131, 9, 1, 2, 'Si &lt;i&gt;x&lt;/i&gt; est Ã©gal au cinquiÃ¨me de ( &lt;i&gt;x&lt;/i&gt; + &lt;i&gt;y&lt;/i&gt; ), alors la valeur de &lt;sup&gt;&lt;i&gt;x &lt;/i&gt;&lt;/sup&gt;&amp;frasl;&lt;sub&gt;&lt;i&gt;y&lt;/i&gt;&lt;/sub&gt; est :', 1),
(132, 9, 1, 3, 'Quel nombre &lt;i&gt;n&lt;/i&gt; vÃ©rifie lâ€™Ã©quation (10&lt;sup&gt;-5&lt;/sup&gt; x 10&lt;sup&gt;&lt;i&gt;n&lt;/i&gt;&lt;/sup&gt;)&lt;sup&gt;2&lt;/sup&gt; / (10 x 10&lt;sup&gt;-4&lt;/sup&gt;) = 1000 ?', 1),
(133, 9, 1, 2, 'Les nombres &lt;i&gt;a&lt;/i&gt;, &lt;i&gt;b&lt;/i&gt; et &lt;i&gt;c&lt;/i&gt; sont trois rÃ©els non nuls.&lt;br/&gt;Le nombre &lt;i&gt;X&lt;/i&gt; = (-2&lt;i&gt;a&lt;/i&gt;.&lt;i&gt;b&lt;/i&gt;&lt;sup&gt;2&lt;/sup&gt;)&lt;sup&gt;2&lt;/sup&gt; / (&lt;i&gt', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
