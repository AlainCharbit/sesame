﻿<!DOCTYPE html>
<html>
<head>
	<title>Quizz</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
	<form class="form-horizontal" method="post" action="quizz.php">
	<fieldset>
	
	<!-- Form Name -->
	<legend>Choix du quizz</legend>
	
	<!-- Select Basic -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="idDiscipline">Discipline</label>
	  <div class="col-md-4">
	    <select id="idDiscipline" name="idDiscipline" class="form-control">
	      <option value="1">Anglais</option>
	      <option value="2">Allemand</option>
	      <option value="3">Espagnol</option>
	      <option value="4">Italien</option>
	      <option value="5">Portugais</option>
	      <option value="6">Arabe</option>
	      <option value="7">Chinois</option>
	      <option value="8">Russe</option>
	      <option value="9">Logique</option>
	    </select>
	  </div>
	</div>
	
	<!-- Select Basic -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="difficulteQuizz">Difficulté</label>
	  <div class="col-md-4">
	    <select id="difficulteQuizz" name="difficulteQuizz" class="form-control">
	      <option value="1">Facile</option>
	      <option value="2">Normal</option>
	      <option value="3">Difficile</option>
	    </select>
	  </div>
	</div>
	
	<!-- Button -->
	<div class="form-group">
	  <label class="col-md-4 control-label" for="submit"></label>
	  <div class="col-md-4">
	    <button id="submit" name="submit" class="btn btn-primary">Commencer le quizz</button>
	  </div>
	</div>
	
	</fieldset>
	</form>
</body>
</html>

<?php

session_start();

// Redirection vers la page pour répondre au quizz si l'utilisateur n'a pas finis de dépondre a un quizz.
if (isset($_SESSION['idQuestion']) && $_SESSION['idQuestion'] != 0) 
{
	header("Location: quizz-1.php");
}

// Création du quizz quand les paramètres du quizz ont été choisis via le formulaire ci dessus.
if (isset($_POST['idDiscipline']) && isset($_POST['difficulteQuizz']))
{

	// Sécurisation des valeurs reçu via le formulaire.
	$idDiscipline = htmlspecialchars($_POST['idDiscipline']);
	$difficulteQuizz = htmlspecialchars($_POST['difficulteQuizz']);

	// Connexion à la base de donnée
	include_once('Classes/Connexion.php');
	$db = Connexion::ouvrir();

	// Sélection des questions aléatoirement en fonction des paramètres choisis dans le formulaire.
	$req = $db->prepare('SELECT * FROM questions WHERE idDiscipline = ? AND difficulteQuestion = ? ORDER BY RAND() * (SELECT COUNT(ID) FROM questions) LIMIT 10');
	$req->execute(array($_POST['idDiscipline'], $_POST['difficulteQuizz']));

	// Enregistrement des questions dans un tableau
	while ($donnees = $req->fetch())
	{
		$questions[] = $donnees['ID'];
	}
	
	// Enregistrement de la discipline, de la difficulté, et des questions du quizz dans la base de donnée en récupérant les valeurs du tableau des questions.
	$req=$db->prepare("INSERT INTO quizz (idDiscipline, difficulteQuizz, idQuestion1, idQuestion2, idQuestion3, idQuestion4, idQuestion5, idQuestion6, idQuestion7, idQuestion8, idQuestion9, idQuestion10) VALUES (:idDiscipline, :difficulteQuizz, :idQuestion1, :idQuestion2, :idQuestion3, :idQuestion4, :idQuestion5, :idQuestion6, :idQuestion7, :idQuestion8, :idQuestion9, :idQuestion10)");
	$req->bindParam(':idDiscipline', $idDiscipline);
	$req->bindParam(':difficulteQuizz', $difficulteQuizz);
	$req->bindParam(':idQuestion1', $questions[0]);
	$req->bindParam(':idQuestion2', $questions[1]);
	$req->bindParam(':idQuestion3', $questions[2]);
	$req->bindParam(':idQuestion4', $questions[3]);
	$req->bindParam(':idQuestion5', $questions[4]);
	$req->bindParam(':idQuestion6', $questions[5]);
	$req->bindParam(':idQuestion7', $questions[6]);
	$req->bindParam(':idQuestion8', $questions[7]);
	$req->bindParam(':idQuestion9', $questions[8]);
	$req->bindParam(':idQuestion10', $questions[9]);
	$req->execute();

	$idQuizz = $db->lastInsertId(); // Sélection de l'ID du quizz créé pour l'enregistrer dans l'historique de l'utilisateur.
	$idCandidat = 1; // Ici on devra récupérer l'ID de l'utilisateur connecté pour l'enregistrer dans la base de donnée [JULES <3]
	$note = 0; // Sa note au début du quizz est de 0, elle augmentera en fonction des réponses juste.

	// Création de l'historique du quizz pour l'utilisateur connecté, avec l'ID de son quizz, la date et sa note.
	$req=$db->prepare("INSERT INTO historique (dateQuizz, note, idCandidat, idQuizz) VALUES (NOW(), :note, :idCandidat, :idQuizz)");
	$req->bindParam(':note', $note);
	$req->bindParam(':idCandidat', $idCandidat);
	$req->bindParam(':idQuizz', $idQuizz);
	$req->execute();

	$idHistorique = $db->lastInsertId(); // Sélection de l'id de l'historique.

	$_SESSION['idQuizz'] = $idQuizz; // Enregistrement de l'ID du quizz dans une variable session pour poser les questions du quizz.
	$_SESSION['idHistorique'] = $idHistorique; // Enregistrement de l'ID dans une variable session de l'historique pour mettre à jour la note par la suite.
	$_SESSION['idQuestion'] = 1; // Création d'une variable session pour retenir la question en cours, on commence par la 1ère.

	header("Location: quizz-1.php"); // Redirection vers la page pour répondre au quizz.
}

?>