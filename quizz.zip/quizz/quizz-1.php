﻿<?php

session_start();

// Redicrection vers la page de création du quizz si n'a pas de quizz en cours.
if (!isset($_SESSION['idQuestion']) || $_SESSION['idQuestion'] == 0) 
{
	header("Location: quizz.php");
}

// Connexion à la base de donnée.
include_once('Classes/Connexion.php');
$db = Connexion::ouvrir();

// Récupération des variables de session.
$idQuizz = $_SESSION['idQuizz'];
$idHistorique = $_SESSION['idHistorique'];

// Imporation des questions du quizz.
$req = $db->prepare('SELECT * FROM quizz WHERE ID = ?');
$req->execute(array($idQuizz));
while ($donnees = $req->fetch())
{
	$idQuestion1 = $donnees['idQuestion1'];
	$idQuestion2 = $donnees['idQuestion2'];
	$idQuestion3 = $donnees['idQuestion3'];
	$idQuestion4 = $donnees['idQuestion4'];
	$idQuestion5 = $donnees['idQuestion5'];
	$idQuestion6 = $donnees['idQuestion6'];
	$idQuestion7 = $donnees['idQuestion7'];
	$idQuestion8 = $donnees['idQuestion8'];
	$idQuestion9 = $donnees['idQuestion9'];
	$idQuestion10 = $donnees['idQuestion10'];
}

// Sélection de la question en cour grâce à la variable session de la question en cour.
if ($_SESSION['idQuestion'] == 1) { $idQuestion = $idQuestion1; }
elseif ($_SESSION['idQuestion'] == 2) { $idQuestion = $idQuestion2; }
elseif ($_SESSION['idQuestion'] == 3) { $idQuestion = $idQuestion3; }
elseif ($_SESSION['idQuestion'] == 4) { $idQuestion = $idQuestion4; }
elseif ($_SESSION['idQuestion'] == 5) { $idQuestion = $idQuestion5; }
elseif ($_SESSION['idQuestion'] == 6) { $idQuestion = $idQuestion6; }
elseif ($_SESSION['idQuestion'] == 7) { $idQuestion = $idQuestion7; }
elseif ($_SESSION['idQuestion'] == 8) { $idQuestion = $idQuestion8; }
elseif ($_SESSION['idQuestion'] == 9) { $idQuestion = $idQuestion9; }
elseif ($_SESSION['idQuestion'] == 10) { $idQuestion = $idQuestion10; }

// Si la valeur de la question en cour a dépassé 10 le quizz est terminé.
else
{
	// Sélection de la note finale pour l'afficher.
	$req = $db->prepare('SELECT * FROM historique WHERE ID = ?');
	$req->execute(array($idHistorique));
	while ($donnees = $req->fetch())
	{
		echo 'Félicitations, vous avez terminé le quizz avec une note de '. $donnees['note'] .'<br/>';
		echo '<a href="quizz.php">Faire une autre tentative</a>';
	}

	// Remise à 0 de la variable de session de la question en cours.
	$_SESSION['idQuestion'] = 0;

	exit; // Comme le quizz est terminé il est inutile d'éxécuter la suite du code (ça permet d'éviter les erreurs).
}

// Si aucune réponse n'a été envoyé, c'est qu'on attends la question.
if (!isset($_POST['idReponse']))
{

	// Sélection et affichage de la question.
	$req = $db->prepare('SELECT * FROM questions WHERE ID = ?');
	$req->execute(array($idQuestion));
	while ($donnees = $req->fetch())
	{
		echo $donnees['enonceQuestion'] . '<br/><br/>';
	}
	
	// Sélection et affichage des réponses possibles qui corespondent à la question.
	$req = $db->prepare('SELECT * FROM reponses WHERE idQuestion = ?');
	$req->execute(array($idQuestion));
	while ($donnees = $req->fetch())
	{
		echo '	<form method="post" action="quizz-1.php">
					<input type="hidden" value="'. $donnees['ID'] .'" id="idReponse" name="idReponse"></input>
					<button id="submit" name="submit">'. $donnees['ennonceReponse'] .'</button>
				</form>';
	}
}

// Sinon, une réponse à été sélectionné donc on affiche sa correction et on ajoute +1 à la note si la réponse est juste.
else
{	
	$idReponse = htmlspecialchars($_POST['idReponse']); // Récupération et sécurisation de la réponse envoyé.

	// Sélection et affichage de la correction de la question.
	$req = $db->prepare('SELECT * FROM reponses WHERE ID = ?');
	$req->execute(array($idReponse));
	while ($donnees = $req->fetch())
	{
		echo ''. $donnees['correctionReponse'] .'';
		$resultatReponse = $donnees['resultatReponse'];
	}

	// On ajoute +1 à la note dans l'historique si la réponse est juste.
	if ($resultatReponse == 1) {
		$req=$db->prepare('UPDATE historique SET note = note + 1 WHERE ID = :ID');
		$req->bindParam(':ID', $idHistorique);
		$req->execute();
	}

	$_SESSION['idQuestion']++; // Incrémentation de la question et cours.
	echo '<br/><a href="quizz-1.php">Question suivante</a>'; // Lien pour aller vers la question suivante.
}

?>