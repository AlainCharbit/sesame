<?php

// Connexion à la base de donnée.
include_once('../Classes/Connexion.php');

// Récupération des valeurs du formulaire.
$ID = $_POST['ID'];

// Supression d'une ligne dans la base de donnée.
$db = Connexion::ouvrir();
$req=$db->prepare('DELETE FROM questions WHERE ID = :ID');
$req->bindParam(':ID', $ID);
$req->execute();
header('Location: index.html');

?>