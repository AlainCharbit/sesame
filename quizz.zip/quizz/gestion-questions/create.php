﻿<?php

// Connexion à la base de donnée.
include_once('../Classes/Connexion.php');

// Récupération des valeurs du formulaire.
$idDiscipline = $_POST['idDiscipline'];
$difficulteQuestion = $_POST['difficulteQuestion'];
$enonceQuestion = $_POST['enonceQuestion'];
$recurrenceQuestion = $_POST['recurrenceQuestion'];

// Insertion d'une ligne dans la base de donnée.
$db = Connexion::ouvrir();
$req=$db->prepare("INSERT INTO questions (idDiscipline, difficulteQuestion, enonceQuestion, recurrenceQuestion) VALUES (:idDiscipline, :difficulteQuestion, :enonceQuestion, :recurrenceQuestion)");
$req->bindParam(':idDiscipline', $idDiscipline);
$req->bindParam(':difficulteQuestion', $difficulteQuestion);
$req->bindParam(':enonceQuestion', $enonceQuestion);
$req->bindParam(':recurrenceQuestion', $recurrenceQuestion);
$req->execute();
header('Location: index.html');

?>