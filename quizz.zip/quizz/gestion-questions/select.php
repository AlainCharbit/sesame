﻿<?php

// Connexion à la base de donnée.
include_once('../Classes/Connexion.php');

// Sélection de l'utilisateur
$ID = $_POST['ID'];

// Sélection d'une ligne dans la base de donnée.
$db = Connexion::ouvrir();
$req = $db->prepare('SELECT * FROM questions WHERE ID = ?');
$req->execute(array($ID));

// Affichage du résultat
while ($donnees = $req->fetch())
{
	echo 'Question : ' . $donnees['enonceQuestion'] . '<br/>Difficulté : ' . $donnees['difficulteQuestion'] . '<br/>Discipline : ' . $donnees['idDiscipline'] . '<br/>Récurrence : ' . $donnees['recurrenceQuestion'] . '';
}

?>